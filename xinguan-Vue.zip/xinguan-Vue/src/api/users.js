import request from '../utils/request'

/**
 * 后面的每次请求都是需要携带token的
 * @returns {AxiosPromise}
 */
export const findUserList = (currentPage, size) => {
  return request({
    url: "/user/findUserListRest/"+currentPage+"/"+size,
    method: 'get'
  })
}

export const findUserList2 = () => {
  return request({
    url: '/user/findUserList',
    method: 'get'
  })
}

/**
 * 视频里的写法，更贴近axios官方的用法，作用和第一个findUserList一样。
 */
export const findUserList3 = (currentPage, pageSize) => {
  return request({
    url: '/user/findUserList',
    method: 'get',
    params: {
      currentPage,
      pageSize
    }
  })
}

