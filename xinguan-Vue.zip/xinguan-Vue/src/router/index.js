import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    //重定向到login
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login')
  },
  {
    path: '/main',
    name: 'Main',
    component: () => import('../views/Main'),
    children: [
      {
        path: '/users',
        name: 'Users',
        component: () => import('../views/user/Users'),
        meta: {title: '用户管理'}
      }
    ]
  },

]

const router = new VueRouter({
  routes
})

export default router
