import axios from 'axios'

const instance = axios.create({
  baseURL: 'http://localhost:8082/system',
  timeout: 3000,
});

//暴露出去，别的组件可以直接使用
export default instance;
