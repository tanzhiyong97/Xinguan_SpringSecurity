<template>
  <div>
    <!--面包屑-->
    <el-breadcrumb separator="/" style="padding-left: 10px; padding-bottom: 10px; font-size: 14px">
      <el-breadcrumb-item :to="{ path: '/main' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item><a href="/">系统管理</a></el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!--用户列表卡片-->
    <el-card class="box-card">
      <el-form :inline="true" :model="formInline" class="demo-form-inline">
        <el-form-item label="城市">
          <el-select v-model="value" placeholder="请选择">
            <el-option
              v-for="item in formInline.cities"
              :key="item.value"
              :label="item.label"
              :value="item.value">
              <span style="float: left">{{ item.label }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户名">
          <el-input v-model="formInline.username" placeholder="请输入用户名"></el-input>
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="formInline.email" placeholder="请输入邮箱"></el-input>
        </el-form-item>
        <el-form-item label="昵称">
          <el-input v-model="formInline.nickName" placeholder="请输入昵称"></el-input>
        </el-form-item>
        <el-radio v-model="formInline.radio" label="1">男</el-radio>
        <el-radio v-model="formInline.radio" label="2">女</el-radio>
        <el-radio v-model="formInline.radio" label="3">全部</el-radio>

        <el-form-item style="margin-left: 10px">
          <el-button icon="el-icon-refresh"  @click="onSubmit">重置</el-button>
          <el-button type="primary" icon="el-icon-search"  @click="onSubmit">查询</el-button>
          <el-button type="success" icon="el-icon-plus"  @click="onSubmit">添加</el-button>
          <el-button type="warning" icon="el-icon-download"  @click="downExcel">导出</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!--表格内容显示区域-->
    <el-table
      :data="tableData"
      border
      fit="true"
      height="730"
      max-height="100%"
      style="width: 100%;">
      <el-table-column
        prop="nickname"
        label="用户名"
        min-width="12%">
      </el-table-column>
      <el-table-column
        prop="username"
        label="姓名"
        min-width="12%">
      </el-table-column>
      <el-table-column
        prop="sex"
        label="性别"
        min-width="8%">
        <template slot-scope="scope">
          {{scope.row.sex==0?'男':(scope.row.sex==1?'女':'保密')}}
        </template>
      </el-table-column>
      <el-table-column
        prop="email"
        sortable
        align="center"
        min-width="20%"
        label="邮箱">
      </el-table-column>
      <el-table-column
        prop="birth"
        sortable
        label="生日"
        min-width="20%"
        align="center">
      </el-table-column>
      <el-table-column
        prop="phoneNumber"
        label="电话"
        min-width="20%"
        align="center">
      </el-table-column>
      <el-table-column
        prop="status"
        label="是否禁用"
       min-width="8%">
        <template slot-scope="scope">
          <el-switch
              v-model="scope.row.status==1"
              active-color="#13ce66"
              inactive-color="#ff4949">
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column
        min-width="20%"
        label="操作">
        <el-button type="primary" size="min" icon="el-icon=edit">编辑</el-button>
        <el-button type="warning" size="min" icon="el-icon=delete">删除</el-button>
        <el-button type="success" size="min" icon="el-icon=option">操作</el-button>
      </el-table-column>
    </el-table>

    <!--分页-->
    <el-pagination
      style="padding-top: 15px"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
  import { findUserList, findUserList2 } from '../../api/users'

  export default {
    name: 'Users',
    data() {
      return {
        formInline: {
          username: '',
          email: '',
          radio: '1',
          nickName: '',
          cities: [],
        },
        tableData: [{
          nickname: '',
          username: '',
          email: '',
          phoneNumber: '',
          status: ''

        }],
        currentPage: 1,
        pageSize: 10,
        total: 0,
        value: ''
      }
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      },
      downExcel() {

      },
      async getUserList2() {
        const {data} = await findUserList2()
        console.log(data);
        this.tableData = data.data.records;
        this.total = data.data.total;
      },
      async getUserList() {
        const {data} = await findUserList(this.currentPage, this.pageSize);
        this.tableData = data.data.records;
        console.log(data)
      },
      handleSizeChange(val) {
        this.pageSize = val;
        this.getUserList();
      },
      handleCurrentChange(val) {
        this.$data.currentPage = val;
        this.getUserList();
      }
    },
    created() {
      //创建组件的时候调用查询所有用户的方法
      this.getUserList2()
    }
  }
</script>

<style scoped>

</style>
