<template>
    <div>
      <!--v-for遍历所有的menuList-->
      <template v-for="item in this.menuList">
        <!--v-if判断是否有子菜单，有的话才遍历，因为这个层次是submenu，节点菜单到el-menu-item中展示-->
        <el-submenu :disabled="item.disabled" :index="item.id+''" :key="item.id+''" v-if="item.children.length>0">
          <template slot="title">
            <i :class="item.icon"></i>
            <span slot="title">{{item.menuName}}</span>
          </template>
          <!--子元素用递归的思想-->
          <MenuTree :menuList="item.children"></MenuTree>
        </el-submenu>
        <el-menu-item
        v-else
        :disabled="item.disabled"
        :index="item.url+''"
        :route="item.url+''"
        :key="item.id">
          <i :class="item.icon"></i>
          <span slot="title">{{item.menuName}}</span>
        </el-menu-item>
      </template>
    </div>
</template>

<script>
  export default {
    name: 'MenuTree',
    data() {
      return{

      }
    },
    props: ["menuList", "toggleList"]
  }
</script>

<style scoped>

  /*实现了一个溢出处理*/
  .el-menu--collapse span,
  .el-menu--collapse i.el-submenu__icon-arrow {
    height: 0;
    width: 0;
    overflow: hidden;
    visibility: hidden;
    display: inline-block;

  }
</style>
